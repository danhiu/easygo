import { useDispatch } from "react-redux";
import { Button } from "react-bootstrap";
import { closeModal } from "../../../store/modalSlice";

function LoginModal() {
  const dispatch = useDispatch();
  const handleModalClose = () => {
    dispatch(closeModal());
  };
  const handleLogin = () => {
    handleModalClose();
  };
  return (
    <div>
      <h2>登录模态窗口</h2>

      <Button onClick={handleModalClose}>取消</Button>
      <Button onClick={handleLogin}>登录</Button>
    </div>
  );
}

export default LoginModal;
