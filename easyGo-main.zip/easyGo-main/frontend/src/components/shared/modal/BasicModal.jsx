import { useDispatch, useSelector } from "react-redux";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { selectModal } from "../../../store/modalSlice";
import { closeModal } from "../../../store/modalSlice";

function BasicModal() {
  const dispatch = useDispatch();
  const { modalType, isOpen } = useSelector(selectModal);
  const handleModalClose = () => {
    dispatch(closeModal());
  };
  return (
    <Modal show={isOpen} onHide={handleModalClose}>
      <Modal.Header closeButton>
        <Modal.Title>模态框标题</Modal.Title>
      </Modal.Header>
      <Modal.Body>哇喔，你正在以模态框阅读此文本!</Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleModalClose}>
          关闭
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default BasicModal;
