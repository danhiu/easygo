import ListGroup from "react-bootstrap/ListGroup";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Button from "react-bootstrap/Button";

function OrderDelivery(props) {
  return (
    <ListGroup className="mb-4">
      <ListGroup.Item>配送信息</ListGroup.Item>
      <ListGroup.Item>邮寄状态 : {props.deliveryStatus}</ListGroup.Item>
      <ListGroup.Item>
        <Row>
          <Col>
            <p>接收人: {props.name}</p>
            <p>地址</p>
            <p>城市 : {props.address.city}</p>
            <p>街道 : {props.address.street}</p>
            <p>邮编 : {props.address.zipcode}</p>
          </Col>
        </Row>
      </ListGroup.Item>
    </ListGroup>
  );
}

export default OrderDelivery;
