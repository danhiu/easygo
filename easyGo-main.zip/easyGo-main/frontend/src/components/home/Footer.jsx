import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const Footer = () => {
  return (
    <footer className="bg-dark text-white py-5">
      <Container>
        <Row>
          <Col md={4}>
            <h5>易小购</h5>
            <p>这是一个简单的电子商务网站,提供各种商品供您选购。</p>
          </Col>
          <Col md={2}>
            <h5>团队</h5>
            <ul className="list-unstyled">
              <li>关于我们</li>
              <li>商城</li>
              <li>博客</li>
            </ul>
          </Col>
          <Col md={3}>
            <h5>联系</h5>
            <ul className="list-unstyled">
              <li>联系我们</li>
              <li>xxxxxxxxxx xxxxxxx xxxx xxx xxx</li>
              <li>+xx xxx xxx xxx xxx</li>
              <li>xxx@xxx.com</li>
            </ul>
          </Col>
          <Col md={3}>
            <h5>通讯</h5>
            <p>当出现新内容时,您会收到通知。</p>
            <form>
              <div className="mb-3">
                <input type="email" className="form-control" placeholder="输入您的电子邮件" />
              </div>
              <button type="submit" className="btn btn-primary">订阅</button>
            </form>
          </Col>
        </Row>
        <hr className="my-4" />
        <Row>
          <Col className="text-center">
            <p>&copy; 2024 版权所有</p>
            <ul className="list-inline">
              <li className="list-inline-item">
                <a href="#" className="text-white">条款与服务</a>
              </li>
              <li className="list-inline-item">
                <a href="#" className="text-white">隐私政策</a>
              </li>
            </ul>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;