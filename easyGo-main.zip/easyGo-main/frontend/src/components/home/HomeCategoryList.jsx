import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Spinner from "react-bootstrap/Spinner";
import AlertExtraContent from "../shared/AlertExtraContent";
import { Link } from "react-router-dom";
import styles from "./HomeCategoryList.module.css";
import Button from "react-bootstrap/Button"; // 导入 Button 组件

import { useGetCategorysQuery } from "../../api/extendedCategoryApiSlice";

function HomeCategoryList() {
  const {
    data: categorys,
    isLoading,
    isSuccess,
    isError,
    error,
  } = useGetCategorysQuery();

  let content;

  if (isLoading) {
    content = (
      <Spinner animation="border" role="status">
        <span className="visually-hidden">加载中...</span>
      </Spinner>
    );
  } else if (isSuccess) {
    content = categorys.data.map((category) => (
      <Col key={category.id}>
        <Link className={styles.categorylink} to={`/category/${category.id}`}>
        <Button variant="outline-primary" className={styles.categoryButton}>
            {category.name}
          </Button>
        </Link>
      </Col>
    ));
  } else if (isError) {
    content = (
      <Col xs={8}>
        <AlertExtraContent
          variant="danger"
          heading="糟糕! 发生错误!"
          content={error.error.toString()}
        />
      </Col>
    );
  }

  return (
    <Container>
      <Row className="g-2">{content}</Row>
    </Container>
  );
}

export default HomeCategoryList;
