import Carousel from "react-bootstrap/Carousel";
import { Image } from "react-bootstrap";
import "./Carousel.css";

function CarouselExample() {
  return (
    <Carousel>
      <Carousel.Item className="carousel-item">
        <Image
          className="carousel-image"
          src="/carousel-image-1.jpg"
          alt="First slide"
        />
        <Carousel.Caption>
          <h3>沙发</h3>
          <p>没有生命，没有自由，只有光辉照耀着柔软。</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item className="carousel-item">
        <Image
          className="carousel-image"
          src="/carousel-image-2.jpg"
          alt="Second slide"
        />

        <Carousel.Caption>
          <h3>床</h3>
          <p>客户至关重要，因为有了客户，我们才能顺利前行。</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item className="carousel-item">
        <Image
          className="carousel-image"
          src="/carousel-image-3.jpg"
          alt="Third slide"
        />

        <Carousel.Caption>
          <h3>椅子</h3>
          <p>
          舒适、时尚的椅子，让您享受每一刻。现在购买，为您的家居增添品质与风格！
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default CarouselExample;
