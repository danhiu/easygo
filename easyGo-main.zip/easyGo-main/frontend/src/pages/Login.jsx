import { Container } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Alert from "react-bootstrap/Alert";

import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { onLogin } from "../api/authFetch";
import { createToast } from "../store/toastSlice";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

const schema = yup
  .object()
  .shape({
    email: yup.string().email().required("需要电子邮箱"),
    password: yup
      .string()
      .min(8)
      .max(15)
      .required("密码必须为 8 - 15 个字符."),
  })
  .required();

function Login() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // data : {email, password}
  // user : user-email
  const onSubmit = async (data) => {
    try {
      const payload = await onLogin(data);
      dispatch(
        createToast({
          type: "success",
          description: "登陆成功!",
        })
      );
      navigate("/");
    } catch (err) {
      if (!err?.originalStatus) {
        // isLoading: true until timeout occurs
      } else if (err.originalStatus === 400) {
        console.error("错误：缺少用户名或密码");
      } else if (err.originalStatus === 401) {
        console.error("错误：未经授权");
      } else {
        console.error("错误：登录失败");
      }
      dispatch(
        createToast({
          type: "danger",
          description: "登录失败。请重试!",
        })
      );
    }
  };

  const {
    register,
    handleSubmit,
    formState: { isSubmitting, isDirty, errors },
  } = useForm({ resolver: yupResolver(schema) });

  return (
    <Container>
      <Row className="justify-content-md-center ">
        <Col md={4}>
          <h1 className="mt-5">EasyGo 易小购</h1>
          <h3>登录</h3>
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Form.Group className="mt-4 mb-2" controlId="email">
              <Form.Label>邮箱</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入邮箱"
                {...register("email")}
              />
            </Form.Group>
            {errors.email && (
              <Alert variant="danger">{errors.email.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="password">
              <Form.Label>密码</Form.Label>
              <Form.Control
                type="password"
                placeholder="输入密码"
                {...register("password")}
              />
            </Form.Group>
            {errors.password && (
              <Alert variant="danger">{errors.password.message}</Alert>
            )}
            <div className="d-grid gap-2">
              <Button variant="primary" type="submit" disabled={isSubmitting}>
                提交
              </Button>
            </div>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default Login;
