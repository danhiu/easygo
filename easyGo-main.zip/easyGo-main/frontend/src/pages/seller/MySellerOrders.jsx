import { Fragment } from "react";
import { NavLink } from "react-router-dom";

import Spinner from "react-bootstrap/Spinner";
import Container from "react-bootstrap/Container";
import ListGroup from "react-bootstrap/ListGroup";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Button from "react-bootstrap/Button";
import AlertExtraContent from "../../components/shared/AlertExtraContent";

import { useGetLoggedInSellerOrdersQuery } from "../../api/apiSlice";

function MySellerOrders() {
  const {
    data: sellerOrders,
    isLoading,
    isSuccess,
    isError,
    error,
  } = useGetLoggedInSellerOrdersQuery();

  let content;

  if (isLoading) {
    content = (
      <Spinner animation="border" role="status">
        <span className="visually-hidden">加载中...</span>
      </Spinner>
    );
  } else if (isSuccess) {
    content = (
      <Fragment>
        {sellerOrders.data
          .slice()
          .reverse()
          .map((orderItem) => (
            <Row key={orderItem.orderItemId} className="mt-3">
              <ListGroup as="ul">
                <ListGroup.Item as="li" variant="primary">
                  订单日期 : {orderItem.orderDate}
                </ListGroup.Item>
                <ListGroup.Item as="li">
                 订单商品 id : {orderItem.orderItemId}
                </ListGroup.Item>
                <ListGroup.Item as="li">
                 商品 id : {orderItem.itemId}
                </ListGroup.Item>
                <ListGroup.Item as="li">Item : {orderItem.name}</ListGroup.Item>
                <ListGroup.Item as="li">
                 价格 : {orderItem.orderPrice}
                </ListGroup.Item>
                <ListGroup.Item as="li">
                 数量: {orderItem.count}
                </ListGroup.Item>
                <ListGroup.Item as="li">
                  地址:{" "}
                  {`${orderItem.address.city} - ${orderItem.address.street} - ${orderItem.address.zipcode}`}
                </ListGroup.Item>
              </ListGroup>
            </Row>
          ))}
      </Fragment>
    );
  } else if (isError) {
    content = (
      <AlertExtraContent
        variant="danger"
        heading="糟糕! 发生错误!"
        content={"Failed to fetch the resource from server"}
      />
    );
  }

  return (
    <Container>
      <Row>
        <Col md={3}>
          <Row>
            <h2>卖家订单</h2>
            <Button
              variant="btn btn-outline-primary"
              to={`/sellers/me`}
              as={NavLink}
            >
              返回卖家简介
            </Button>
          </Row>
        </Col>
        <Col md={1}></Col>
        <Col md={8}>
          <p className="fw-bold">订单记录</p>
          {content}
        </Col>
      </Row>
    </Container>
  );
}

export default MySellerOrders;
