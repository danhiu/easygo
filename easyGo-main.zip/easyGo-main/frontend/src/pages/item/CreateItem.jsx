import { Container } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Alert from "react-bootstrap/Alert";
import Spinner from "react-bootstrap/Spinner";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { createToast } from "../../store/toastSlice";

import { useAddNewItemMutation } from "../../api/extendedItemApiSlice";
import { useGetCategorysQuery } from "../../api/extendedCategoryApiSlice";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

const schema = yup
  .object()
  .shape({
    categoryId: yup
      .number()
      .positive()
      .integer()
      .required("输入有效类别"),
    name: yup
      .string()
      .min(2)
      .max(100)
      .required("名称必须为 2 - 100 个字符."),
    description: yup
      .string()
      .min(10)
      .max(500)
      .required("描述必须为 10 - 500 个字符."),

    price: yup
      .number()
      .positive()
      .integer()
      .moreThan(1)
      .lessThan(100000000)
      .required("价格必填"),
    stockQuantity: yup
      .number()
      .positive()
      .integer()
      .lessThan(10000000)
      .required("库存数量必须为 50 - 10000000"),
    mainImageUrl: yup.string().url().required("输入有效的图片网址"),
  })
  .required();

function CreateItem() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [
    addNewItem,
    { isError: isAddError, isLoading: isAddLoading, isSuccess: isAddSuccess },
  ] = useAddNewItemMutation();
  const {
    data: categorys,
    isLoading,
    isSuccess,
    isError,
    error,
  } = useGetCategorysQuery();

  let content;
  if (isLoading) {
    content = (
      <Spinner animation="border" role="status">
        <span className="visually-hidden">加载中...</span>
      </Spinner>
    );
  } else if (isSuccess) {
    content = categorys.data.map((category) => (
      <option key={category.id} value={category.id}>
        {category.name}
      </option>
    ));
  } else if (isError) {
    content = <div>存在错误</div>;
  }

  const onSaveItem = async (data) => {
    try {
      const payload = await addNewItem(data).unwrap();
      const sellerId = payload.sellerId;
      dispatch(
        createToast({
          type: "success",
          description: "已注册您的新商品！",
        })
      );
      navigate(`/sellers/me`);
    } catch (err) {
      dispatch(
        createToast({
          type: "danger",
          description: "哎呀，注册您的商品时出了点问题",
        })
      );
      console.error("报错: ", err);
    }
  };

  const {
    register,
    handleSubmit,
    formState: { isSubmitting, isDirty, errors },
  } = useForm({ resolver: yupResolver(schema) });

  return (
    <Container>
      <Row className="justify-content-md-center ">
        <Col md={6}>
          <h1 className="mt-5">EasyGo 易小购</h1>
          <h3>创建新商品</h3>
          <Form onSubmit={handleSubmit(onSaveItem)}>
            <Form.Group className="mt-4 mb-2" controlId="name">
              <Form.Label>名字</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入名字"
                {...register("name")}
              />
            </Form.Group>
            {errors.name && (
              <Alert variant="danger">{errors.name.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="description">
              <Form.Label>描述</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入描述"
                {...register("description")}
              />
            </Form.Group>
            {errors.description && (
              <Alert variant="danger">{errors.description.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="price">
              <Form.Label>价格</Form.Label>
              <Form.Control
                type="number"
                placeholder="输入价格"
                {...register("price")}
              />
            </Form.Group>
            {errors.price && (
              <Alert variant="danger">{errors.price.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="stockQuantity">
              <Form.Label>库存数量</Form.Label>
              <Form.Control
                type="number"
                placeholder="输入数量"
                {...register("stockQuantity")}
              />
            </Form.Group>
            {errors.stockQuantity && (
              <Alert variant="danger">{errors.stockQuantity.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="mainImageUrl">
              <Form.Label>商品图片url</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入 Url"
                {...register("mainImageUrl")}
              />
            </Form.Group>
            {errors.mainImageUrl && (
              <Alert variant="danger">{errors.mainImageUrl.message}</Alert>
            )}
            <Form.Group className="mt-4 mb-2" controlId="categoryId">
              <Form.Label>选择类别</Form.Label>

              <Form.Select
                aria-label="Default select example"
                {...register("categoryId")}
              >
                {content}
              </Form.Select>
            </Form.Group>

            {errors.categoryId && (
              <Alert variant="danger">{errors.categoryId.message}</Alert>
            )}
            <div className="d-grid gap-2">
              <Button
                variant="primary"
                type="submit"
                disabled={isSubmitting || isLoading || isError}
              >
                提交
              </Button>
            </div>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default CreateItem;
