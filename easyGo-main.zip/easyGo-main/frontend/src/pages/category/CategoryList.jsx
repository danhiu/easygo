import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Spinner from "react-bootstrap/Spinner";
import Container from "react-bootstrap/Container";
import Button from "react-bootstrap/Button";
import ButtonGroup from "react-bootstrap/ButtonGroup";
import { NavLink } from "react-router-dom";
import { Fragment } from "react";
import AlertExtraContent from "../../components/shared/AlertExtraContent";
import AddCategoryForm from "../../components/category/AddCategoryForm";

import {
  useGetCategorysQuery,
  useDeleteCategoryMutation,
} from "../../api/extendedCategoryApiSlice";

export const CategoryList = () => {
  const {
    data: categorys,
    isLoading,
    isSuccess,
    isError,
    error,
  } = useGetCategorysQuery();

  const [
    deleteCategory,
    {
      isError: isErrorDelete,
      isLoading: isLoadingDelete,
      isSuccess: isSuccessDelete,
    },
  ] = useDeleteCategoryMutation();

  const onDeleteCategory = async (categoryId) => {
    try {
      const payload = await deleteCategory(categoryId).unwrap();
    } catch (err) {
      console.error("删除类别 错误: ", err);
    }
  };

  let content;
  let categoryList;

  if (isLoading) {
    content = (
      <Spinner animation="border" role="status">
        <span className="visually-hidden">加载中...</span>
      </Spinner>
    );
  } else if (isSuccess) {
    categoryList = categorys.data.map((category) => (
      <Row key={category.id} className="gx-2 mb-2">
        <Col md={2}>{category.id}</Col>
        <Col md={4}>{category.name}</Col>
        <Col md={6}>
          <ButtonGroup aria-label="Basic example">
            <Button
              variant="btn btn-outline-secondary"
              to={`/category/${category.id}`}
              as={NavLink}
            >
              查看
            </Button>
            <Button
              variant="btn btn-outline-secondary"
              to={`/admin/category/${category.id}`}
              as={NavLink}
              className="ml-3"
            >
              修改
            </Button>
            <Button
              variant="danger"
              onClick={() => onDeleteCategory(category.id)}
            >
              删除
            </Button>
          </ButtonGroup>
        </Col>
      </Row>
    ));
    content = (
      <Fragment>
        <AddCategoryForm />
        <div className="mt-5">{categoryList}</div>
      </Fragment>
    );
  } else if (isError) {
    content = (
      <Row>
        <Col xs={8}>
          <AlertExtraContent
            variant="danger"
            heading="糟糕! 发生错误!"
            content={error.error.toString()}
          />
        </Col>
      </Row>
    );
  }

  return (
    <Container>
      <h1>管理员界面</h1>
      <h3>管理类别</h3>
      {content}
    </Container>
  );
};

export default CategoryList;
