import { Fragment } from "react";
import CarouselExample from "../components/home/Carousel";
import Container from "react-bootstrap/Container";
import HomeCategoryList from "../components/home/HomeCategoryList";
import { TrendingItems } from "../components/home/TrendingItems";
import { useState } from "react";
import { useSearchItemsQuery } from "../api/extendedItemApiSlice";
import Spinner from "react-bootstrap/Spinner";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import ItemCard from "../components/shared/ItemCard";

export function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: searchResults, isLoading, isFetching } = useSearchItemsQuery(searchQuery, {
    skip: searchQuery.length === 0, // 只在搜索查询为空时跳过请求
    refetchOnMountOrArgChange: true, // 确保在输入时自动发送请求
  });

  const handleSearch = () => {
    // 搜索逻辑
  };
  return (
    <Fragment>
      <Container>
        <CarouselExample />
        <Container className="my-5">
          <Row className="justify-content-center mb-4">
            <Col xs={10} md={6}>
              <Form.Control
                type="text"
                placeholder="搜索商品..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                size="lg"
                className="rounded-pill"
              />
            </Col>
          </Row>

          {(isLoading || isFetching) ? (
            <div className="text-center">
              <Spinner animation="border" role="status">
                <span className="visually-hidden">加载中...</span>
              </Spinner>
            </div>
          ) : searchResults?.data.length > 0 ? (
            <Card className="shadow">
              <Card.Body>
                <Row>
                  {searchResults.data.map((item) => (
                    <Col key={item.id} xs={6} md={4} lg={3}>
                      <ItemCard
                        id={item.id}
                        name={item.name}
                        price={item.price}
                        mainImageUrl={item.mainImageUrl}
                        sellerName={item.sellerName}
                      />
                    </Col>
                  ))}
                </Row>
              </Card.Body>
            </Card>
          ) : (
            <p className="text-center">没有搜索结果</p>
          )}
        </Container>
        <h3 className="my-4">类别</h3>
        <HomeCategoryList />
        <h3 className="my-4">商品</h3>
        <TrendingItems />
      </Container>
    </Fragment>
  );
}
