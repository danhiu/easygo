import { Container } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Alert from "react-bootstrap/Alert";

import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { createToast } from "../store/toastSlice";
import { useSignUpMutation } from "../api/extendedAuthApiSlice";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

const schema = yup
  .object()
  .shape({
    email: yup.string().email().required("需要电子邮箱"),
    password: yup
      .string()
      .min(8)
      .max(15)
      .required("密码必须为 8 - 15 个字符."),
    name: yup
      .string()
      .min(2)
      .max(15)
      .required("名称必须为 2 - 15 个字符."),
    city: yup
      .string()
      .min(2)
      .max(15)
      .required("城市必须为 2 - 15 个字符."),
    street: yup
      .string()
      .min(2)
      .max(15)
      .required("街道必须为 2 - 15 个字符."),
    zipcode: yup
      .string()
      .min(2)
      .max(15)
      .required("邮政编码必须为 2 - 10 个字符."),
    profileImageUrl: yup.string().url().required("输入有效的图片 url"),
  })
  .required();

function SignUp() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [addNewMember, { isError, isLoading, isSuccess }] = useSignUpMutation();

  const onSaveMember = async (data) => {
    try {
      const payload = await addNewMember(data).unwrap();
      dispatch(
        createToast({
          type: "success",
          heading: "欢迎来到 EasyGo!",
          description: "注册成功 ",
        })
      );
      navigate(`/auth/login`);
    } catch (err) {
      dispatch(
        createToast({
          type: "danger",
          description: "哦不。你的注册出了点问题",
        })
      );
      console.error("报错: ", err);
    }
  };

  const {
    register,
    handleSubmit,
    formState: { isSubmitting, isDirty, errors },
  } = useForm({ resolver: yupResolver(schema) });

  return (
    <Container>
      <Row className="justify-content-md-center ">
        <Col md={6}>
          <h1 className="mt-5">EasyGo 易小购</h1>
          <h3>注册</h3>
          <Form onSubmit={handleSubmit(onSaveMember)}>
            <Form.Group className="mt-4 mb-2" controlId="email">
              <Form.Label>邮箱</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入邮箱"
                {...register("email")}
              />
            </Form.Group>
            {errors.email && (
              <Alert variant="danger">{errors.email.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="password">
              <Form.Label>密码</Form.Label>
              <Form.Control
                type="password"
                placeholder="输入密码"
                {...register("password")}
              />
            </Form.Group>
            {errors.password && (
              <Alert variant="danger">{errors.password.message}</Alert>
            )}
            <Form.Group className="mt-4 mb-2" controlId="name">
              <Form.Label>名字</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入名字"
                {...register("name")}
              />
            </Form.Group>
            {errors.name && (
              <Alert variant="danger">{errors.name.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="city">
              <Form.Label>城市</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入城市"
                {...register("city")}
              />
            </Form.Group>
            {errors.city && (
              <Alert variant="danger">{errors.city.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="street">
              <Form.Label>街道</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入街道"
                {...register("street")}
              />
            </Form.Group>
            {errors.street && (
              <Alert variant="danger">{errors.street.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="zipcode">
              <Form.Label>邮政编码</Form.Label>
              <Form.Control
                type="number"
                placeholder="输入邮政编码"
                {...register("zipcode")}
              />
            </Form.Group>
            {errors.zipcode && (
              <Alert variant="danger">{errors.zipcode.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="profileImageUrl">
              <Form.Label>简介图片 Url</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入 Url"
                {...register("profileImageUrl")}
              />
            </Form.Group>
            {errors.profileImageUrl && (
              <Alert variant="danger">{errors.profileImageUrl.message}</Alert>
            )}

            <div className="d-grid gap-2">
              <Button variant="primary" type="submit" disabled={isSubmitting}>
                提交
              </Button>
            </div>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default SignUp;
