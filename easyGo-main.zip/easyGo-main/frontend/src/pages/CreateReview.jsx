import { Container } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import Alert from "react-bootstrap/Alert";
import { useNavigate, useParams } from "react-router-dom";
import { useAddNewReviewMutation } from "../api/apiSlice";
import { useDispatch } from "react-redux";
import { createToast } from "../store/toastSlice";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

const schema = yup
  .object()
  .shape({
    description: yup
      .string()
      .min(10)
      .max(200)
      .required("评论必须为 10 - 200 个字符."),

    rating: yup
      .number()
      .positive()
      .integer()
      .moreThan(0)
      .lessThan(6)
      .required("需要评分"),
  })
  .required();

function CreateReview() {
  const { itemId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [addNewReview, { isError, isLoading, isSuccess }] =
    useAddNewReviewMutation();

  const onSaveReview = async (data) => {
    try {
      const payload = await addNewReview({
        itemId: itemId,
        newReview: { ...data },
      }).unwrap();
      const reviewId = payload.id;
      dispatch(
        createToast({
          type: "success",
          description: "创建新评论!",
        })
      );
      navigate(`/items/${itemId}`);
    } catch (err) {
      dispatch(
        createToast({
          type: "warning",
          description: "哦，不，出了点问题。再试一次",
        })
      );
      console.error("报错: ", err);
    }
  };

  const {
    register,
    handleSubmit,
    formState: { isSubmitting, isDirty, errors },
  } = useForm({ resolver: yupResolver(schema) });

  return (
    <Container>
      <Row className="justify-content-md-center ">
        <Col md={6}>
          <h1 className="mt-5">EasyGo 易小购</h1>
          <h3>撰写评论</h3>
          <Form onSubmit={handleSubmit(onSaveReview)}>
            <Form.Group className="mt-4 mb-2" controlId="description">
              <Form.Label>描述</Form.Label>
              <Form.Control
                type="text"
                placeholder="输入描述"
                {...register("description")}
              />
            </Form.Group>
            {errors.description && (
              <Alert variant="danger">{errors.description.message}</Alert>
            )}

            <Form.Group className="mt-4 mb-2" controlId="rating">
              <Form.Label>评分</Form.Label>

              <Form.Select
                aria-label="Default select example"
                {...register("rating")}
              >
                <option value="5">5 星</option>
                <option value="4">4 星</option>
                <option value="3">3 星</option>
                <option value="2">2 星</option>
                <option value="1">1 星</option>
              </Form.Select>
            </Form.Group>
            {errors.rating && (
              <Alert variant="danger">{errors.rating.message}</Alert>
            )}

            <div className="d-grid gap-2">
              <Button variant="primary" type="submit" disabled={isSubmitting}>
                提交
              </Button>
            </div>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default CreateReview;
