import { Routes, Route } from "react-router-dom";
import { Container } from "react-bootstrap";
import React, { Fragment, useEffect, useMemo } from "react";
import { Home } from "./pages/Home";
import Seller from "./pages/seller/Seller";
import Item from "./pages/item/Item";
import Cart from "./pages/member/Cart";
import Navbar from "./components/shared/Navbar";

import RequireAuth from "./components/auth/RequireAuth";
import { onReissue } from "./api/authFetch";
import { useNavigate } from "react-router-dom";
import Profile from "./pages/Profile";
import OrderInfo from "./pages/OrderInfo";
import MyOrders from "./pages/member/MyOrders";
import CategoryItemList from "./pages/CategoryItemList";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import SellerSignUp from "./pages/seller/SellerSignUp";
import CreateItem from "./pages/item/CreateItem";
import UpdateItem from "./pages/item/UpdateItem";
import CreateReview from "./pages/CreateReview";
import UpdateMember from "./pages/member/UpdateMember";
import MyProfile from "./pages/member/MyProfile";
import MySellerProfile from "./pages/seller/MySellerProfile";
import CategoryList from "./pages/category/CategoryList";
import UpdateCategory from "./pages/category/UpdateCategory";
import MySellerOrders from "./pages/seller/MySellerOrders";
import Footer from "./components/home/Footer";
import './App.css';
function App() {
  const navigate = useNavigate();
  useEffect(() => {
    window.$crisp = [];
    window.CRISP_WEBSITE_ID = "60f5a7a0-24ab-48d7-be89-cc3749557837";

    const d = document;
    const s = d.createElement("script");
    s.src = "https://client.crisp.chat/l.js";
    s.async = 1;
    d.getElementsByTagName("head")[0].appendChild(s);

    // 在组件卸载时清理Crisp脚本
    return () => {
      s.remove();
    };

    async function refreshThenReissue() {
      onReissue();
    }
    refreshThenReissue();

    navigate("/");
  }, []);

  return (
    <Fragment>
      <Navbar />
      <Container className="app-container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/auth/login" element={<Login />} />
          <Route path="/auth/signup" element={<SignUp />} />
          <Route path="/items/:itemId" element={<Item />} />
          <Route path="/category/:categoryId" element={<CategoryItemList />} />

          {/* protected routes  element={<RequireAuth />}   */}
          <Route path="/" element={<RequireAuth />}>
            <Route path="sellers/:sellerId" element={<Seller />} />
            <Route path="sellers/me" element={<MySellerProfile />} />
            <Route path="sellers/me/orders" element={<MySellerOrders />} />
            <Route path="sellers/signup" element={<SellerSignUp />} />
            <Route path="items/create" element={<CreateItem />} />
            <Route path="items/:itemId/update" element={<UpdateItem />} />
            <Route
              path="items/:itemId/reviews/create"
              element={<CreateReview />}
            />
            <Route path="members/:memberId" element={<Profile />} />
            <Route path="members/me" element={<MyProfile />} />
            <Route path="members/me/updateprofile" element={<UpdateMember />} />
            <Route path="members/cart" element={<Cart />} />
            <Route path="members/orders" element={<MyOrders />} />
            <Route path="orders/:orderId" element={<OrderInfo />} />

            <Route path="admin/category" element={<CategoryList />} />
            <Route path="admin/seller" element={<CategoryList />} />
            <Route path="admin/order" element={<CategoryList />} />
            <Route
              path="admin/category/:categoryId"
              element={<UpdateCategory />}
            />
          </Route>
        </Routes>
      </Container>
      <Footer /> {/* 渲染 Footer 组件 */}
    </Fragment>
  );
}

export default App;
