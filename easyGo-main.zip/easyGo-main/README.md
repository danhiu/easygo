# Easy Go 易小购

一个基于React+Spring Boot的在线网络商城

> 关键词: 网络商城, Spring Boot, React, 前后端分离

## 技术栈

### 前端

- React 

### 后端

- Spring Boot 
- Java JDK 11
- MySQL 8.0
- Gradle

## 前端部署、启动方式

```
npm run install
npm run dev
```

## 前端部署、启动方式

Idea 应用内， Gradle 自动部署，运行Application启动后端

## 数据库部署

部署 EasyGo_db.sql 

## 数据库架构

![](https://img.erpweb.eu.org/imgs/2024/06/e512f3bee0003afe.jpg)
