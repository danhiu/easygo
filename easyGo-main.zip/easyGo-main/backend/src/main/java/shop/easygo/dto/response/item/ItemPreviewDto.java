package shop.easygo.dto.response.item;

import shop.easygo.domain.item.Item;
import lombok.Data;

@Data
public class ItemPreviewDto {

    private Long id;
    private String name;
    private int price;

    private String mainImageUrl;

    private String sellerName;
    private Long sellerId;

    public ItemPreviewDto(Item item){
        id = item.getId();
        name = item.getName();
        price = item.getPrice();
        mainImageUrl = item.getMainImageUrl();
        sellerName = item.getSeller().getCompanyName();
        sellerId = item.getSeller().getId();
    }
}
