package shop.easygo.jwt;

import shop.easygo.dto.auth.TokenDto;
import shop.easygo.service.CustomUserDetailsService;
import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class TokenProvider {

    private static final String AUTHORITIES_KEY = "auth";
    private static final String BEARER_TYPE = "Bearer";
    private static final long ACCESS_TOKEN_EXPIRE_TIME = 1000 * 60 * 30;            // 30分钟
    private static final long REFRESH_TOKEN_EXPIRE_TIME = 1000 * 60 * 60 * 24 * 7;  // 7天

    private final Key key;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    public TokenProvider(@Value("${jwt.secret}") String secretKey) {
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        this.key = Keys.hmacShaKeyFor(keyBytes);
    }

    public TokenDto generateTokenDto(Authentication authentication) {
        // 获取权限
        String authorities = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        long now = (new Date()).getTime();

        // 创建访问令牌
        Date accessTokenExpiresIn = new Date(now + ACCESS_TOKEN_EXPIRE_TIME);
        String accessToken = Jwts.builder()
                .setSubject(authentication.getName())       // payload "sub": "name"
                .claim(AUTHORITIES_KEY, authorities)        // payload "auth": "ROLE_USER"
                .setExpiration(accessTokenExpiresIn)        // payload "exp": 1516239022 (例子)
                .signWith(key, SignatureAlgorithm.HS512)    // header "alg": "HS512"
                .compact();

        // 创建刷新令牌
        String refreshToken = Jwts.builder()
                .setSubject(authentication.getName())       // payload "sub": "name"
                .setExpiration(new Date(now + REFRESH_TOKEN_EXPIRE_TIME))
                .signWith(key, SignatureAlgorithm.HS512)
                .compact();

        log.info("======= 新令牌 ==========");
        log.info("访问令牌");
        log.info(accessToken);
        log.info("刷新令牌");
        log.info(refreshToken);

        return TokenDto.builder()
                .grantType(BEARER_TYPE)
                .accessToken(accessToken)
                .accessTokenExpiresIn(accessTokenExpiresIn.getTime())
                .refreshToken(refreshToken)
                .build();
    }

    public Authentication getAuthentication(String accessToken) {
        // 令牌解密
        Claims claims = parseClaims(accessToken);
        System.out.println("访问声明 = " + claims);

        if (claims.get(AUTHORITIES_KEY) == null) {
            throw new RuntimeException("没有凭证的令牌。");
        }

        // 从声明中获取权限信息
        Collection<? extends GrantedAuthority> authorities =
                Arrays.stream(claims.get(AUTHORITIES_KEY).toString().split(","))
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());

        // 创建 UserDetails 对象并返回 Authentication
        UserDetails principal = new User(claims.getSubject(), "", authorities);

        return new UsernamePasswordAuthenticationToken(principal, "", authorities);
    }

    public Authentication getAuthenticationForRefreshToken(String refreshToken) {
        // 令牌解密
        Claims claims = parseClaims(refreshToken);
        System.out.println("刷新声明 = " + claims);
        long userId = Long.parseLong(claims.getSubject());
        UserDetails userDetails = customUserDetailsService.loadUserByUserId(userId);

        // 创建 UserDetails 对象并返回 Authentication
        UserDetails principal = new User(claims.getSubject(), "", userDetails.getAuthorities());

        return new UsernamePasswordAuthenticationToken(principal, "", userDetails.getAuthorities());
    }



    public boolean validateToken(String token) {
        try {
            // 令牌解密
            Claims claims = parseClaims(token);
            if(claims.getExpiration().before(new Date())){
                log.info("JWT 令牌已过期。");
                return false;
            }
            return true;
        } catch (io.jsonwebtoken.security.SecurityException | MalformedJwtException e) {
            log.info("JWT 签名无效。");
        } catch (ExpiredJwtException e) {
            log.info("JWT 令牌已过期。");
        } catch (UnsupportedJwtException e) {
            log.info("不支持 JWT 令牌。");
        } catch (IllegalArgumentException e) {
            log.info("JWT 令牌无效。");
        }
        return false;
    }

    private Claims parseClaims(String accessToken) {
        try {
            return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(accessToken).getBody();
        } catch (ExpiredJwtException e) {
            return e.getClaims();
        }
    }


}
