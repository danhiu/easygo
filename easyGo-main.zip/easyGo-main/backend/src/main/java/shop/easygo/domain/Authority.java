package shop.easygo.domain;

public enum Authority {
    ROLE_USER, ROLE_SELLER, ROLE_ADMIN
}
