package shop.easygo.dto.request.order;

import lombok.Data;
import shop.easygo.domain.OrderStatus;

@Data
public class UpdateOrderStatusRequest {
    private OrderStatus status;
}
