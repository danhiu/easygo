package shop.easygo.dto.response.order;

import shop.easygo.domain.OrderItem;
import lombok.Data;

@Data
public class OrderItemDto {

    private Long itemId;
    private String itemName;//产品名称
    private String itemImageUrl;
    private int orderPrice; //订单价格
    private int count; //订单数量
    public OrderItemDto(OrderItem orderItem) {
        itemName = orderItem.getItem().getName();
        itemId = orderItem.getItem().getId();
        itemImageUrl = orderItem.getItem().getMainImageUrl();
        orderPrice = orderItem.getOrderPrice();
        count = orderItem.getCount();
    }

}
