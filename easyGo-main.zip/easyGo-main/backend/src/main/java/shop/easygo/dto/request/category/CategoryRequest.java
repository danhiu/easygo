package shop.easygo.dto.request.category;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Data
public class CategoryRequest{
    @NotEmpty
    @Length(max = 30)
    @Pattern(regexp = ".*", message = "name can be any character")
    private String name;
}
