package shop.easygo.repository;

import shop.easygo.domain.Member;
import shop.easygo.domain.Order;
import shop.easygo.domain.OrderSearch;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class OrderRepository {
    private final EntityManager em;

    public void save(shop.easygo.domain.Order order){
        em.persist(order);
    }

    public shop.easygo.domain.Order findOne(Long id){
        return em.find(shop.easygo.domain.Order.class, id);
    }

    public List<shop.easygo.domain.Order> findAll(int offset, int limit){
        return em.createQuery(
                "select o from Order o" +
                        " join fetch o.member m" +
                        " join fetch o.delivery d", shop.easygo.domain.Order.class)
                .setFirstResult(offset)
                .setMaxResults(limit)
                .getResultList();
    }

    public List<shop.easygo.domain.Order> findByMember(Long memberId){
        return em.createQuery(
                        "select o from Order o" +
                                " join fetch o.member m" +
                                " join fetch o.delivery d" +
                                " where m.id = :member", shop.easygo.domain.Order.class)
                .setParameter("member", memberId)
                .getResultList();
    }

    // search with filter

    public List<shop.easygo.domain.Order> findAllWithFilter(OrderSearch orderSearch) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<shop.easygo.domain.Order> cq = cb.createQuery(shop.easygo.domain.Order.class);
        Root<shop.easygo.domain.Order> o = cq.from(shop.easygo.domain.Order.class);
        Join<shop.easygo.domain.Order, Member> m = o.join("member", JoinType.INNER); //与会员一起加入
        List<Predicate> criteria = new ArrayList<>();
        //订单状态查询
        if (orderSearch.getOrderStatus() != null) {
            Predicate status = cb.equal(o.get("status"),
                    orderSearch.getOrderStatus());
            criteria.add(status);
        }
        //会员姓名搜索
        if (StringUtils.hasText(orderSearch.getMemberName())) {
            Predicate name =
                    cb.like(m.<String>get("name"), "%" +
                            orderSearch.getMemberName() + "%");
            criteria.add(name);
        }
        cq.where(cb.and(criteria.toArray(new Predicate[criteria.size()])));
        TypedQuery<Order> query = em.createQuery(cq).setMaxResults(1000); //最多1000个案例
        return query.getResultList();
    }



}
