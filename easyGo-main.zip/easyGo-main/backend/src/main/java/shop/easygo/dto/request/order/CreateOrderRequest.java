package shop.easygo.dto.request.order;

import shop.easygo.domain.item.ItemIdQuantity;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
public class CreateOrderRequest {

    @NotEmpty
    private List<ItemIdQuantity> itemIdQuantityList;
}


