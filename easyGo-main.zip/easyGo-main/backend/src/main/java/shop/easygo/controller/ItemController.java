package shop.easygo.controller;

import shop.easygo.domain.Authority;
import shop.easygo.domain.Member;
import shop.easygo.domain.item.Item;
import shop.easygo.dto.request.item.CreateItemRequest;
import shop.easygo.dto.request.item.UpdateItemRequest;
import shop.easygo.dto.response.item.CreateItemResponse;
import shop.easygo.dto.response.item.ItemDto;
import shop.easygo.dto.response.item.ItemPreviewDto;
import shop.easygo.repository.ItemRepository;
import shop.easygo.service.ItemService;
import shop.easygo.service.MemberService;
import shop.easygo.util.SecurityUtil;
import shop.easygo.exception.UnauthorizedMemberException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/api/items")
public class ItemController {

    private final ItemService itemService;
    private final MemberService memberService;
    private final ItemRepository itemRepository;

    @PostMapping
    public CreateItemResponse create(@RequestBody @Valid CreateItemRequest request) throws Exception {
        Long sellerId = verifySeller();
        Long id = itemService.createItem(sellerId, request.getName(), request.getPrice(), request.getStockQuantity(), request.getDescription(), request.getMainImageUrl(), request.getCategoryId());
        return new CreateItemResponse(sellerId);
    }

    @GetMapping("/search")
    public Result<List<ItemPreviewDto>> searchItemsByName(@RequestParam("name") String name) {
        List<Item> items = itemRepository.findByNameContaining(name);
        List<ItemPreviewDto> itemPreviews = items.stream()
                .map(ItemPreviewDto::new)
                .collect(Collectors.toList());
        return new Result<>(itemPreviews);
    }

    // Find One Item with its reviews
    @GetMapping("/{itemId}")
    public ItemDto itemWithReviews(@PathVariable("itemId") Long itemId){
        Item findItem = itemService.findOne(itemId);
        System.out.println("findItem = " + findItem);
        return new ItemDto(findItem);
    }

    // Read ALL items
    @GetMapping
    public Result itemsList(@RequestParam(value = "offset", defaultValue = "0") int offset,
                            @RequestParam(value = "limit", defaultValue = "100") int limit){
        List<Item> findItems = itemRepository.findAll(offset, limit);
        List<ItemPreviewDto> collect = findItems.stream()
                .map(i -> new ItemPreviewDto(i))
                .collect(Collectors.toList());
        return new Result(collect);
    }

    @PatchMapping("/{itemId}")
    public Result updateItem(@PathVariable("itemId") Long itemId, @RequestBody @Valid UpdateItemRequest request) throws Exception{
        Long sellerId = verifySeller();
        Long id = itemService.updateItem(itemId, request.getName(), request.getPrice(), request.getStockQuantity(), request.getDescription(), request.getMainImageUrl());
        return new Result(sellerId);

    }

    private Long verifySeller(){
        Member findMember = memberService.findOne(SecurityUtil.getCurrentMemberId());
        if (findMember.getAuthority().equals(Authority.ROLE_USER)) {
            throw new UnauthorizedMemberException();
        }
        return findMember.getSeller().getId();
    }



    @Data
    @AllArgsConstructor
    static class Result<T>{
        private T data;
    }
}
