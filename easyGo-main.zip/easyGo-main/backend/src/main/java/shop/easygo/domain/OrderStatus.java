package shop.easygo.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
