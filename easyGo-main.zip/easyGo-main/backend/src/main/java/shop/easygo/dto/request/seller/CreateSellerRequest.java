package shop.easygo.dto.request.seller;

import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.URL;

import javax.validation.constraints.*;

@Data
public class CreateSellerRequest {

    @NotBlank
    @Pattern(regexp = ".*", message = "name can be any character")
    @Length(min=2, max=15)
    private String companyName;

    @NotNull
    @Email
    private String companyEmail;

    @NotNull
    @URL
    private String companyImageUrl;
}
