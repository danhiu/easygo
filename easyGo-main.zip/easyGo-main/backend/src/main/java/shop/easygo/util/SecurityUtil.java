package shop.easygo.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

@Slf4j
public class SecurityUtil {

    private SecurityUtil() { }

    // 当SecurityContext中存储用户信息时
    // 当请求进来时，保存到JwtFilter的doFilter中
    public static Long getCurrentMemberId() {
        final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || authentication.getName() == null) {
            throw new RuntimeException("安全上下文中没有身份验证信息.");
        }

        return Long.parseLong(authentication.getName());
    }
}
