package shop.easygo.domain;

public enum DeliveryStatus {
    READY, COMP
}
