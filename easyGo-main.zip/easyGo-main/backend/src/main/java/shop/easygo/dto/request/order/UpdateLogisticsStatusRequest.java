package shop.easygo.dto.request.order;

import lombok.Data;

@Data
public class UpdateLogisticsStatusRequest {
    private String logisticsStatus;
}
