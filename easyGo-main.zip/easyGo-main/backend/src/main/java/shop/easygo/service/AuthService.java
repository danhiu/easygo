package shop.easygo.service;

import shop.easygo.domain.Member;
import shop.easygo.domain.RefreshToken;
import shop.easygo.dto.auth.MemberRequestDto;
import shop.easygo.dto.auth.MemberResponseDto;
import shop.easygo.dto.auth.TokenDto;
import shop.easygo.dto.request.member.CreateMemberRequest;
import shop.easygo.jwt.TokenProvider;
import shop.easygo.repository.MemberRepository;
import shop.easygo.repository.RefreshTokenRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {
    private final AuthenticationManagerBuilder authenticationManagerBuilder;
    private final MemberRepository memberRepository;
    private final PasswordEncoder passwordEncoder;
    private final TokenProvider tokenProvider;
    private final RefreshTokenRepository refreshTokenRepository;

    @Transactional
    public MemberResponseDto signup(CreateMemberRequest createMemberRequest) {
        if (memberRepository.existsByEmail(createMemberRequest.getEmail())) {
            throw new RuntimeException("您已经是注册用户");
        }

        Member member = createMemberRequest.toMember(passwordEncoder);
        return MemberResponseDto.of(memberRepository.save(member));
    }

    @Transactional
    public TokenDto login(MemberRequestDto memberRequestDto) {
        // 1. 根据登录ID/PW生成AuthenticationToken
        UsernamePasswordAuthenticationToken authenticationToken = memberRequestDto.toAuthentication();

        // 2. 实际进行验证（用户密码检查）的部分
        //    当执行authenticate方法时，会执行CustomUserDetailsService中创建的loadUserByUsername方法。
        Authentication authentication = authenticationManagerBuilder.getObject().authenticate(authenticationToken);

        // 3. 根据认证信息生成JWT token
        TokenDto tokenDto = tokenProvider.generateTokenDto(authentication);

        // 4. RefreshToken 保存
        RefreshToken refreshToken = RefreshToken.builder()
                .key(authentication.getName())
                .value(tokenDto.getRefreshToken())
                .build();

        refreshTokenRepository.save(refreshToken);

        // 5. 通证发行
        return tokenDto;
    }

    @Transactional
    public TokenDto reissue(String cookieRefreshToken) {
        // 1. Refresh Token 确认
        if (!tokenProvider.validateToken(cookieRefreshToken)) {
            throw new RuntimeException("Refresh Token 是无效的.");
        }

        // 2.  获取 Member ID
        Authentication authentication = tokenProvider.getAuthenticationForRefreshToken(cookieRefreshToken);

        // 3. 根据存储库中的 Member ID 检索刷新令牌值
        RefreshToken refreshToken = refreshTokenRepository.findByKey(authentication.getName())
                .orElseThrow(() -> new RuntimeException("用户已退出."));

        // 4. Refresh Token 检查它们是否匹配
        if (!refreshToken.getValue().equals(cookieRefreshToken)) {
            log.info("==============期望 ==============");
            log.info(refreshToken.getValue());
            log.info("==============实际 ==============");
            log.info(cookieRefreshToken);
            throw new RuntimeException("Refresh 令牌用户信息不匹配.");
        }

        // 5. 创建新令牌
        TokenDto tokenDto = tokenProvider.generateTokenDto(authentication);

        // 6. 更新存储库信息
        RefreshToken newRefreshToken = refreshToken.updateValue(tokenDto.getRefreshToken());
        refreshTokenRepository.save(newRefreshToken);

        // 通证发行
        return tokenDto;
    }

    public void logout(String cookieRefreshToken) {
        // 1. Refresh Token 刷新
        if (!tokenProvider.validateToken(cookieRefreshToken)) {
            throw new RuntimeException("Refresh Token 无效.");
        }

        // 2.  获取 Member ID
        Authentication authentication = tokenProvider.getAuthenticationForRefreshToken(cookieRefreshToken);

        // 3. 根据存储库中的 Member ID 检索刷新 Refresh Token
        RefreshToken refreshToken = refreshTokenRepository.findByKey(authentication.getName())
                .orElseThrow(() -> new RuntimeException("用户已退出."));

        // 4. 检查 Refresh Token 是否匹配
        if (!refreshToken.getValue().equals(cookieRefreshToken)) {
            throw new RuntimeException("令牌用户信息不匹配.");
        }

        // 5. 删除存储库中的刷新令牌
        refreshTokenRepository.delete(refreshToken);
    }
}
