package shop.easygo.dto.response.item;

import shop.easygo.domain.CategoryItem;
import lombok.Data;

@Data
public class CategoryItemDto {

    private String categoryName;
    private Long categoryId;

    public CategoryItemDto(CategoryItem categoryItem){
        categoryName = categoryItem.getCategory().getName();
        categoryId = categoryItem.getCategory().getId();
    }
}
