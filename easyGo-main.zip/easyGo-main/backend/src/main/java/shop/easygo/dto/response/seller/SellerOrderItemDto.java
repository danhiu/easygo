package shop.easygo.dto.response.seller;

import shop.easygo.domain.Address;
import shop.easygo.domain.OrderItem;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SellerOrderItemDto {

    private Long orderItemId;
    private Long itemId;
    private String name;
    private int orderPrice;
    private int count;
    private LocalDateTime orderDate; //下单时间
    private Address address;

    public SellerOrderItemDto(OrderItem orderItem){
        orderItemId = orderItem.getId();
        itemId = orderItem.getItem().getId();
        name = orderItem.getItem().getName();
        orderPrice = orderItem.getOrderPrice();
        count = orderItem.getCount();
        orderDate = orderItem.getOrder().getOrderDate();
        address = orderItem.getOrder().getDelivery().getAddress();
    }
}
