package shop.easygo.config;

import shop.easygo.jwt.JwtAccessDeniedHandler;
import shop.easygo.jwt.JwtAuthenticationEntryPoint;
import shop.easygo.jwt.TokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {
    private final TokenProvider tokenProvider;
    private final JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
    private final JwtAccessDeniedHandler jwtAccessDeniedHandler;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // 忽略所有相关API以确保h2数据库测试顺利。
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring()
                .antMatchers("/h2-console/**");
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // CSRF 설정 Disable
        http.cors().and().csrf().disable()

                // 添加异常处理时创建的类
                .exceptionHandling()
                .authenticationEntryPoint(jwtAuthenticationEntryPoint)
                .accessDeniedHandler(jwtAccessDeniedHandler)

                // 添加 h2-console 设置
                .and()
                .headers()
                .frameOptions()
                .sameOrigin()

                // 安全性主要使用会话。
                // 由于我们在这里不使用会话，因此将会话设置设置为 Stateless
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)

                // 登录和会员注册API请求是在没有令牌的情况下发出的，因此设置permitAll。
                .and()
                .authorizeRequests()
                .antMatchers("/auth/**").permitAll()
                .mvcMatchers(HttpMethod.GET,"/api/category/**").permitAll()
                .mvcMatchers(HttpMethod.GET,"/api/items/**").permitAll()
                .anyRequest().authenticated()   // 나머지 API 는 전부 인증 필요

                // 应用通过 addFilterBefore 注册 JwtFilter 的 JwtSecurityConfig 类
                .and()
                .apply(new JwtSecurityConfig(tokenProvider));

        return http.build();
    }
}
