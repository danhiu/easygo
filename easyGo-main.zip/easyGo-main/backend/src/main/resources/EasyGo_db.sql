-- MySQL导出工具版本10.13,适用于Win64 (x86_64)
--
-- 主机: localhost    数据库: shophsedb
-- ------------------------------------------------------
-- 服务器版本 8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */; -- 设置字符集为utf8mb4

/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */; -- 设置时区为UTC
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart` -- 购物车表结构
--

DROP TABLE IF EXISTS `cart`; -- 如果购物车表存在则删除
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` ( -- 创建购物车表
                        `cart_id` bigint NOT NULL, -- 购物车ID,bigint类型,不能为空
                        `count` int NOT NULL, -- 商品数量,int类型,不能为空
                        `item_id` bigint DEFAULT NULL, -- 商品ID,bigint类型,可以为空
                        `member_id` bigint DEFAULT NULL, -- 会员ID,bigint类型,可以为空
                        PRIMARY KEY (`cart_id`), -- 设置主键为cart_id
                        KEY `FK9fhia6b3ekuddn6pkxlsks7rr` (`item_id`), -- 创建外键索引,指向item表的item_id
                        KEY `FKix170nytunweovf2v9137mx2o` (`member_id`), -- 创建外键索引,指向member表的member_id
                        CONSTRAINT `FK9fhia6b3ekuddn6pkxlsks7rr` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`), -- 设置item_id为外键,关联item表的item_id
                        CONSTRAINT `FKix170nytunweovf2v9137mx2o` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) -- 设置member_id为外键,关联member表的member_id
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart` -- 购物车表的数据
--

LOCK TABLES `cart` WRITE; -- 锁定cart表防止其他操作
/*!40000 ALTER TABLE `cart` DISABLE KEYS */; -- 暂时禁用插入数据时对键的检查,提高导入效率
/*!40000 ALTER TABLE `cart` ENABLE KEYS */; -- 开启对键的检查
UNLOCK TABLES; -- 解锁cart表

--
-- Table structure for table `category` -- 商品分类表结构
--

DROP TABLE IF EXISTS `category`; -- 如果分类表存在则删除
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
                            `category_id` bigint NOT NULL, -- 分类ID,bigint类型,不能为空
                            `name` varchar(255) DEFAULT NULL, -- 分类名称,varchar(255)类型,可以为空
                            PRIMARY KEY (`category_id`) -- 设置主键为category_id
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category` -- 分类表的数据
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES
                           (6,'Sofa'),(7,'Bed'),(8,'Wooden'),(9,'Fabric'),(10,'Plastic');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_item` -- 商品分类与商品关联表结构
--

DROP TABLE IF EXISTS `category_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_item` (
                                 `category_item_id` bigint NOT NULL, -- 关联ID,bigint类型,不能为空
                                 `category_id` bigint DEFAULT NULL, -- 分类ID,bigint类型,可以为空,外键关联category表
                                 `item_id` bigint DEFAULT NULL, -- 商品ID,bigint类型,可以为空,外键关联item表
                                 PRIMARY KEY (`category_item_id`), -- 设置主键为category_item_id
                                 KEY `FKcq2n0opf5shyh84ex1fhukcbh` (`category_id`), -- 创建category_id的索引
                                 KEY `FKu8b4lwqutcdq3363gf6mlujq` (`item_id`), -- 创建item_id的索引
                                 CONSTRAINT `FKcq2n0opf5shyh84ex1fhukcbh` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`), -- 设置category_id为外键,关联category表
                                 CONSTRAINT `FKu8b4lwqutcdq3363gf6mlujq` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) -- 设置item_id为外键,关联item表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_item` -- 分类与商品关联表的数据
--

LOCK TABLES `category_item` WRITE;
/*!40000 ALTER TABLE `category_item` DISABLE KEYS */;
INSERT INTO `category_item` VALUES
                                (11,6,16),(12,7,17),(13,8,20),(14,9,19),(15,10,21);
/*!40000 ALTER TABLE `category_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery` -- 配送信息表结构
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery` (
                            `delivery_id` bigint NOT NULL, -- 配送ID,bigint类型,不能为空
                            `city` varchar(255) DEFAULT NULL, -- 城市名,varchar(255)类型,可以为空
                            `street` varchar(255) DEFAULT NULL, -- 街道名,varchar(255)类型,可以为空
                            `zipcode` varchar(255) DEFAULT NULL, -- 邮政编码,varchar(255)类型,可以为空
                            `status` varchar(255) DEFAULT NULL, -- 配送状态,varchar(255)类型,可以为空
                            PRIMARY KEY (`delivery_id`) -- 设置主键为delivery_id
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery` -- 配送表的数据
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES
                           (24,'Seoul','Sejong','55555','READY'), -- 插入一条配送记录
                           (31,'Tokyo','Asakusa','22222','READY'); -- 插入另一条配送记录
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence` -- hibernate序列表结构,用于自增主键
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hibernate_sequence` (
    `next_val` bigint DEFAULT NULL -- 下一个可用的自增值,bigint类型,可以为空
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence` -- 序列表的数据
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (36); -- 插入当前序列值为36
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item` -- 商品表结构
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item` (
                        `item_id` bigint NOT NULL, -- 商品ID,bigint类型,不能为空
                        `description` varchar(255) DEFAULT NULL, -- 商品描述,varchar(255)类型,可以为空
                        `main_image_url` varchar(255) DEFAULT NULL, -- 商品主图URL,varchar(255)类型,可以为空
                        `name` varchar(255) DEFAULT NULL, -- 商品名称,varchar(255)类型,可以为空
                        `price` int NOT NULL, -- 商品价格,int类型,不能为空
                        `stock_quantity` int NOT NULL, -- 库存数量,int类型,不能为空
                        `seller_id` bigint DEFAULT NULL, -- 卖家ID,bigint类型,可以为空,外键关联seller表
                        PRIMARY KEY (`item_id`), -- 设置主键为item_id
                        KEY `FK6uaxabvefkq2n38dmyb4y2qj7` (`seller_id`), -- 创建seller_id索引
                        CONSTRAINT `FK6uaxabvefkq2n38dmyb4y2qj7` FOREIGN KEY (`seller_id`) REFERENCES `seller` (`seller_id`) -- 设置seller_id为外键,关联seller表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item` -- 商品表数据
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES
                       (16,'Cuddle up in the comfortable AdamsSOFA. The generous size invites you and your guests to many hours of socialising and relaxation.','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80','AdamsSOFA',20000,98,3), -- 插入一条商品记录
                       (17,'BBring a cosy feeling into your bedroom. Relax and chill.','https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80','AdamsBED',40000,96,3), -- 插入另一条商品记录
                       (18,'An easy match with different tables and rooms, anywhere and everywhere.','https://images.unsplash.com/photo-1517705008128-361805f42e86?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80','AdamsCHAIR',15000,100,3),
                       (19,'Enjoy long movie nights and comfy socialising with friends in BettySOFA','https://images.unsplash.com/photo-1540574163026-643ea20ade25?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80','BettySOFA',10000,99,5),
                       (20,'Sleep tight in BettyBed. Sheets woven with finest fabric.','https://images.unsplash.com/photo-1566665797739-1674de7a421a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80','BettyBED',30000,97,5),
                       (21,'A comfy chair that’s sturdy, yet lightweight and stackable too.','https://images.unsplash.com/photo-1576528418822-5ddc2568621b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80','BettyCHAIR',16000,100,5);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member` -- 会员表结构
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
                          `member_id` bigint NOT NULL, -- 会员ID,bigint类型,不能为空
                          `city` varchar(255) DEFAULT NULL, -- 城市,varchar(255)类型,可以为空
                          `street` varchar(255) DEFAULT NULL, -- 街道,varchar(255)类型,可以为空
                          `zipcode` varchar(255) DEFAULT NULL, -- 邮政编码,varchar(255)类型,可以为空
                          `authority` varchar(255) DEFAULT NULL, -- 权限,varchar(255)类型,可以为空
                          `email` varchar(255) DEFAULT NULL, -- 邮箱,varchar(255)类型,可以为空
                          `name` varchar(255) DEFAULT NULL, -- 姓名,varchar(255)类型,可以为空
                          `password` varchar(255) DEFAULT NULL, -- 密码,varchar(255)类型,可以为空
                          `profile_image_url` varchar(255) DEFAULT NULL, -- 头像URL,varchar(255)类型,可以为空
                          `seller_id` bigint DEFAULT NULL, -- 卖家ID,bigint类型,可以为空,外键关联seller表
                          PRIMARY KEY (`member_id`), -- 设置主键为member_id
                          KEY `FKnu5u7jteo50pi9vriifmn3af9` (`seller_id`), -- 创建seller_id索引
                          CONSTRAINT `FKnu5u7jteo50pi9vriifmn3af9` FOREIGN KEY (`seller_id`) REFERENCES `seller` (`seller_id`) -- 设置seller_id为外键,关联seller表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member` -- 会员表数据
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES
                         (1,'Seoul','Seoul','11111','ROLE_ADMIN','admin@yomail.com','Admin','$2a$10$FzJIXc3qLSwo1SWNa1Ug/uEVfFvfGhpYU2wMcRzuUy5gc.VrKwh6y','https://assets.website-files.com/5e51c674258ffe10d286d30a/5e535da9550b762cb4f909a6_peep-103.png', NULL), -- 插入一条管理员记录
                         (2,'Paris','Montaigne','11167','ROLE_SELLER','sellerA@yomail.com','sellerA','$2a$10$gfNyVdTKBOe/cFvPEhYxVuBb9zMYiX/1eU1qC/Eg4SCEuRFOZJVIK','https://assets.website-files.com/5e51c674258ffe10d286d30a/5e535741f5fa1a13a1f8f233_peep-48.png',3), -- 插入一条卖家记录
                         (4,'Busan','Busan','22222','ROLE_SELLER','sellerB@yomail.com','sellerB','$2a$10$jyo8FG30trrVwAs20OXO.un6GBE/7ssIpP5YpbZD186rGF6a4hAuG','https://assets.website-files.com/5e51c674258ffe10d286d30a/5e53536a9588e087617bd93c_peep-23.png',5), -- 插入另一条卖家记录
                         (22,'Seoul','Sejong','55555','ROLE_USER','userA@yomail.com','userA','$2a$10$Sj6its3MSXmiVjLgDKC4cOAYBgGQ8yj1n6KwzO7NW0vmSlYbcK7V.','https://assets.website-files.com/5e51c674258ffe10d286d30a/5e535741f5fa1a13a1f8f233_peep-48.png', NULL), -- 插入一条普通用户记录
                         (29,'Tokyo','Asakusa','22222','ROLE_USER','userB@yomail.com','userB','$2a$10$t3naHx3cHwEHTwIVVPJ3N.qmVfKg8/jAx9CH/gPJvFBiIQxMSWYQi','https://assets.website-files.com/5e51c674258ffe10d286d30a/5e5353362b568a99fd167467_peep-21.png', NULL); -- 插入另一条普通用户记录
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item` -- 订单项表结构
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item` (
                              `order_item_id` bigint NOT NULL, -- 订单项ID,bigint类型,不能为空
                              `count` int NOT NULL, -- 商品数量,int类型,不能为空
                              `order_price` int NOT NULL, -- 订单价格,int类型,不能为空
                              `item_id` bigint DEFAULT NULL, -- 商品ID,bigint类型,可以为空,外键关联item表
                              `order_id` bigint DEFAULT NULL, -- 订单ID,bigint类型,可以为空,外键关联orders表
                              `seller_id` bigint DEFAULT NULL, -- 卖家ID,bigint类型,可以为空,外键关联seller表
                              PRIMARY KEY (`order_item_id`), -- 设置主键为order_item_id
                              KEY `FKija6hjjiit8dprnmvtvgdp6ru` (`item_id`), -- 创建item_id索引
                              KEY `FKt4dc2r9nbvbujrljv3e23iibt` (`order_id`), -- 创建order_id索引
                              KEY `FKkm143c4ij6p9540mlmhe443uv` (`seller_id`), -- 创建seller_id索引
                              CONSTRAINT `FKija6hjjiit8dprnmvtvgdp6ru` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`), -- 设置item_id为外键,关联item表
                              CONSTRAINT `FKkm143c4ij6p9540mlmhe443uv` FOREIGN KEY (`seller_id`) REFERENCES `seller` (`seller_id`), -- 设置seller_id为外键,关联seller表
                              CONSTRAINT `FKt4dc2r9nbvbujrljv3e23iibt` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) -- 设置order_id为外键,关联orders表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item` -- 订单项表数据
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES
                             (25,2,20000,16,23,3), -- 插入一条订单项记录
                             (26,4,40000,17,23,3), -- 插入另一条订单项记录
                             (32,1,10000,19,30,5),
                             (33,3,30000,20,30,5);
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders` -- 订单表结构
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
                          `order_id` bigint NOT NULL, -- 订单ID,bigint类型,不能为空
                          `order_date` datetime(6) DEFAULT NULL, -- 下单时间,datetime(6)类型,可以为空
                          `status` varchar(255) DEFAULT NULL, -- 订单状态,varchar(255)类型,可以为空
                          `delivery_id` bigint DEFAULT NULL, -- 配送ID,bigint类型,可以为空,外键关联delivery表
                          `member_id` bigint DEFAULT NULL, -- 会员ID,bigint类型,可以为空,外键关联member表
                          PRIMARY KEY (`order_id`), -- 设置主键为order_id
                          KEY `FKtkrur7wg4d8ax0pwgo0vmy20c` (`delivery_id`), -- 创建delivery_id索引
                          KEY `FKpktxwhj3x9m4gth5ff6bkqgeb` (`member_id`), -- 创建member_id索引
                          CONSTRAINT `FKpktxwhj3x9m4gth5ff6bkqgeb` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`), -- 设置member_id为外键,关联member表
                          CONSTRAINT `FKtkrur7wg4d8ax0pwgo0vmy20c` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`delivery_id`) -- 设置delivery_id为外键,关联delivery表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders` -- 订单表数据
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
                         (23,'2024-06-01 06:29:42.247882','ORDER',24,22), -- 插入一条订单记录
                         (30,'2024-06-01 06:29:42.417326','ORDER',31,29); -- 插入另一条订单记录
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_token` -- 刷新令牌表结构
--

DROP TABLE IF EXISTS `refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_token` (
                                 `rt_key` varchar(255) NOT NULL, -- 刷新令牌键,varchar(255)类型,不能为空
                                 `rt_value` varchar(255) DEFAULT NULL, -- 刷新令牌值,varchar(255)类型,可以为空
                                 PRIMARY KEY (`rt_key`) -- 设置主键为rt_key
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_token` -- 刷新令牌表数据(暂无数据)
--

LOCK TABLES `refresh_token` WRITE;
/*!40000 ALTER TABLE `refresh_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review` -- 评论表结构
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     =@@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
                          `review_id` bigint NOT NULL, -- 评论ID,bigint类型,不能为空
                          `description` varchar(255) DEFAULT NULL, -- 评论内容,varchar(255)类型,可以为空
                          `rating` int NOT NULL, -- 评分,int类型,不能为空
                          `item_id` bigint DEFAULT NULL, -- 商品ID,bigint类型,可以为空,外键关联item表
                          `member_id` bigint DEFAULT NULL, -- 会员ID,bigint类型,可以为空,外键关联member表
                          PRIMARY KEY (`review_id`), -- 设置主键为review_id
                          KEY `FK6hb6qqehnsm7mvfgv37m66hd7` (`item_id`), -- 创建item_id索引
                          KEY `FKk0ccx5i4ci2wd70vegug074w1` (`member_id`), -- 创建member_id索引
                          CONSTRAINT `FK6hb6qqehnsm7mvfgv37m66hd7` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`), -- 设置item_id为外键,关联item表
                          CONSTRAINT `FKk0ccx5i4ci2wd70vegug074w1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) -- 设置member_id为外键,关联member表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review` -- 评论表数据
--

LOCK TABLES `review` WRITE;
/*!40101 SET @saved_cs_client     =@@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
INSERT INTO `review` VALUES
                         (27,'Great sofa for its price! Highly recommend',4,16,22), -- 插入一条评论记录
                         (28,'Bed is comfortable. A bit small though',3,17,22), -- 插入另一条评论记录
                         (34,'SSofa is comfortable. Size is big enough',4,19,29),
                         (35,'Great bed! Size is perfect for me',5,20,29);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seller` -- 卖家表结构
--

DROP TABLE IF EXISTS `seller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seller` (
                          `seller_id` bigint NOT NULL, -- 卖家ID,bigint类型,不能为空
                          `company_email` varchar(255) DEFAULT NULL, -- 公司邮箱,varchar(255)类型,可以为空
                          `company_image_url` varchar(255) DEFAULT NULL, -- 公司图片URL,varchar(255)类型,可以为空
                          `company_name` varchar(255) DEFAULT NULL, -- 公司名称,varchar(255)类型,可以为空
                          PRIMARY KEY (`seller_id`) -- 设置主键为seller_id
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seller` -- 卖家表数据
--

LOCK TABLES `seller` WRITE;
/*!40000 ALTER TABLE `seller` DISABLE KEYS */;
INSERT INTO `seller` VALUES
                         (3,'lovefurniture@yomail.com','https://...','LoveFurniture'), -- 插入一条卖家记录
                         (5,'homeinterior@yomail.com','https://...','HomeInterior'); -- 插入另一条卖家记录
/*!40000 ALTER TABLE `seller` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-01  6:19:46 -- 导出完成于2024年6月1日 06:19:46